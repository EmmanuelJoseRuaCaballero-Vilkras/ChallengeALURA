package mensajes;

import javax.swing.JOptionPane;

public class Mensajes {
    public Mensajes() {
    }

    public int mensajeOpcion() {
        return Integer.parseInt(JOptionPane.showInputDialog(
                "BIENVENIDO, ELIJA SU CONVERTIDOR:\n 1. Convertidor de monedas\n 2. Convertidor distancia\n 3. Salir"));
    }

    public int mensajeMoneda() {
        return Integer.parseInt(JOptionPane.showInputDialog(
                "Elija UNA OPCION\n 1. Convertir de Pesos Colombianos a Dolar\n 2. Convertir de Pesos Colombianos a Euros\n 3. Convertir de Pesos Colombianos a Libras Esterlinas\n 4. Convertir de Pesos Colombianos a Yen Japones\n 5. Convertir de Pesos Colombianos a Won sul-coreano\n 6. Convertir de Dolar a Pesos Colombianos\n 7. Convertir de Euros a Pesos Colombianos\n 8. Convertir de Libras Esterlinas a Pesos Colombianos\n 9. Convertir de Yen Japones a Pesos Colombianos\n 10. Convertir de Won sul-coreano a Pesos Colombianos\n 11. Regresar"));
    }

    public int mostrarMenuDistancia() {
        return Integer.parseInt(JOptionPane.showInputDialog(null, "1. Kilometros a Millas\n 2. Millas a Kilometros\n 3. Metros a Pies\n 4.Pies a Metros\n 5. Salir"));
    }

    public void mensajeError() {
        JOptionPane.showMessageDialog(null, "Error elija una opcion correcta");
    }

    public void mensajeCambio(int op, double dinero, double totalcambio, String moneda) {
        if (op >= 1 && op <= 5) {
            JOptionPane.showMessageDialog(null,
                    "Pesos Colombianos a cambiar: " + dinero + "\nTotal cambio a " + moneda +
                            ": " + totalcambio);
        } else if (op >= 6 && op <= 10) {
            JOptionPane.showMessageDialog(null, moneda + " a cambiar: " + dinero + "\nTotal cambio a Pesos Colombianos: " + totalcambio);
        }
    }
}
