package monedas;

public class monedasWorld {
    private double dolar = 4172.5;
    private double euro = 4552.2;
    private double libraEsterlinas = 5301.0;
    private double yenJapones = 28.90;
    private double wonSulCoreano = 3.16;

    public monedasWorld() {}
    
    public double getDolar() {
        return dolar;
    }
    public double getEuro() {
        return euro;
    }
    public double getLibraEsterlinas() {
        return libraEsterlinas;
    }
    public double getYenJapones() {
        return yenJapones;
    }
    public double getWonSulCoreano() {
        return wonSulCoreano;
    }

    public float cambioMoneda(int op, double moneda, double pesototal) {
        if(op >= 1 && op <=5) {
            return (float) (pesototal / moneda);
        } else if(op >= 6 && op <= 10) {
            return (float) (pesototal * moneda);
        }
        return 0;
    }
}
