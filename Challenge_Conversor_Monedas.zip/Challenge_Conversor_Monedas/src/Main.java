import javax.swing.JOptionPane;

import distancias.distancias;
import mensajes.Mensajes;
import monedas.monedasWorld;

public class Main {
    public static void main(String[] args) {
        Mensajes mensajes = new Mensajes();
        int opcion = 0;
        do {
            opcion = mensajes.mensajeOpcion();
            boolean sw = true;
            switch (opcion) {
                case 1:   
                    while (sw) {
                        int op = Math.abs(mensajes.mensajeMoneda());
                        if (op == 11) {
                            opcion = 0;
                            break;
                        } else if (op > 11) {
                            mensajes.mensajeError();
                        } else {
                            monedasWorld mw = new monedasWorld();
                            double pesototal = Double.parseDouble(JOptionPane.showInputDialog("Ingresa el valor a cambiar: "));
                            if(op == 1) {
                                mensajes.mensajeCambio(op, pesototal, mw.cambioMoneda(op, mw.getDolar(), pesototal), "dolar");
                            } else if(op == 2) {
                                mensajes.mensajeCambio(op, pesototal, mw.cambioMoneda(op, mw.getEuro(), pesototal), "euro");
                            } else if(op == 3) {
                                mensajes.mensajeCambio(op, pesototal, mw.cambioMoneda(op, mw.getLibraEsterlinas(), pesototal), "libra esterlinas");
                            } else if(op == 4) {
                                mensajes.mensajeCambio(op, pesototal, mw.cambioMoneda(op, mw.getYenJapones(), pesototal), "yen japones");
                            } else if(op == 5) {
                                mensajes.mensajeCambio(op, pesototal, mw.cambioMoneda(op, mw.getWonSulCoreano(), pesototal), "won sul coreano");
                            } else if(op == 6) {
                                mensajes.mensajeCambio(op, pesototal, mw.cambioMoneda(op, mw.getDolar(), pesototal), "Dolares");
                            } else if(op == 7) {
                                mensajes.mensajeCambio(op, pesototal, mw.cambioMoneda(op, mw.getEuro(), pesototal), "Euros");
                            } else if(op == 8) {
                                mensajes.mensajeCambio(op, pesototal, mw.cambioMoneda(op, mw.getLibraEsterlinas(), pesototal), "Libras Esterlinas");
                            } else if(op == 9) {
                                mensajes.mensajeCambio(op, pesototal, mw.cambioMoneda(op, mw.getYenJapones(), pesototal), "Yen Japones");
                            } else if(op == 10) {
                                mensajes.mensajeCambio(op, pesototal, mw.cambioMoneda(op, mw.getWonSulCoreano(), pesototal), "Won Sul Coreano");
                            }
                            sw = false;
                        }
                    }
                    break;
                case 2:
                    while(sw) {
                        int op = Math.abs(mensajes.mostrarMenuDistancia());
                        if (op == 5) {
                            opcion = 0;
                            break;
                        } else if (op > 6) {
                            mensajes.mensajeError();
                        } else {
                            distancias dis = new distancias();
                            if (op == 1) {
                                dis.convertirKilometrosAMillas();
                            } else if(op == 2) {
                                dis.convertirMillasAKilometros();
                            } else if(op == 3) {
                                dis.convertirMetrosAPies();
                            } else if(op == 4) {
                                dis.convertirPiesAMetros();
                            }
                            sw = false;
                        }
                    }
                    break;    
                default:
                    mensajes.mensajeError();
                    break;
            }
        } while (opcion != 3);
    }
}
