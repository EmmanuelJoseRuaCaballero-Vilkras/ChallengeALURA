package distancias;

import javax.swing.JOptionPane;

public class distancias {
    public void convertirKilometrosAMillas() {
        
        double kilometros = Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese la cantidad de kilómetros: "));
        double millas = kilometros * 0.621371;
        JOptionPane.showMessageDialog(null, kilometros + " kilómetros equivalen a " + millas + " millas.");
    }

    public void convertirMillasAKilometros() {
        double millas = Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese la cantidad de millas: "));
        double kilometros = millas / 0.621371;
        JOptionPane.showMessageDialog(null, millas + " millas equivalen a " + kilometros + " kilómetros.");
    }

    public void convertirMetrosAPies() {
        double metros = Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese la cantidad de metros "));
        double pies = metros * 3.28084;
        JOptionPane.showMessageDialog(null, metros + " metros equivalen a " + pies + " pies.");
    }

    public void convertirPiesAMetros() {
        double pies = Double.parseDouble(JOptionPane.showInputDialog(null, "Ingrese la cantidad de pies: "));
        double metros = pies / 3.28084;
        JOptionPane.showMessageDialog(null, pies + " pies equivalen a " + metros + " metros.");
    }
}
